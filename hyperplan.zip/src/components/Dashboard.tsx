import React from 'react';
import { 
  Dumbbell, 
  CheckCircle2, 
  RotateCcw, 
  Frown, 
  ArrowRight,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AppState } from '../types';

interface DashboardProps {
  state: AppState;
  onSwitchTab: (tab: string) => void;
}

export default function Dashboard({ state, onSwitchTab }: DashboardProps) {
  const totalMesos = state.mesociclosGenerados.length;
  
  let totalSessions = 0;
  let completedSessions = 0;
  let totalFatiga = 0;
  let fatigaCount = 0;
  const fatigaHistory: number[] = [];

  state.mesociclosGenerados.forEach(meso => {
    const num = meso.num;
    for (let sem = 1; sem <= 4; sem++) {
      Object.keys(meso.datos).forEach(diaKey => {
        const diaData = meso.datos[diaKey];
        if (diaData.ejercicios.length === 0) return;
        
        totalSessions++;
        const tk = state.tracking[num]?.[sem]?.[diaKey];
        if (tk?.completada) {
          completedSessions++;
          // Calculate session avg fatiga
          const ratedExercises = Object.values(tk.ejercicios).filter(e => e.fatiga > 0);
          if (ratedExercises.length > 0) {
            const avg = ratedExercises.reduce((s, e) => s + e.fatiga, 0) / ratedExercises.length;
            totalFatiga += avg;
            fatigaCount++;
            fatigaHistory.push(avg);
          }
        }
      });
    }
  });

  const avgFatiga = fatigaCount > 0 ? (totalFatiga / fatigaCount).toFixed(1) : '—';
  const showDeloadWarning = state.ciclosSinDescargaExtra >= 3;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold tracking-tight mb-2">¡Hola, Atleta! 💪</h1>
        <p className="text-app-muted text-sm">
          Planificador de Sobrecarga Progresiva · {new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </header>

      {showDeloadWarning && (
        <div className="bg-linear-to-r from-amber-lt to-[#FFF3CC] border-2 border-amber-brand rounded-2xl p-6 flex items-center gap-6 animate-in fade-in zoom-in duration-500">
          <div className="w-12 h-12 bg-amber-brand/10 rounded-full flex items-center justify-center text-amber-brand shrink-0">
            <AlertCircle size={28} />
          </div>
          <div>
            <h4 className="font-bold text-amber-brand">Descarga Obligatoria Próxima</h4>
            <p className="text-xs text-app-text/80 mt-1">
              Has completado 3 ciclos consecutivos sin descarga adicional. La semana 10 <strong>DEBE</strong> ser una semana de descarga, independientemente de la evaluación.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <StatCard 
          icon={<Dumbbell className="text-primary" size={20} />}
          label="Mesociclos"
          value={totalMesos}
          sub="generados"
          bgColor="bg-primary-lt"
        />
        <StatCard 
          icon={<CheckCircle2 className="text-teal-brand" size={20} />}
          label="Sesiones"
          value={completedSessions}
          sub={`de ${totalSessions} totales`}
          bgColor="bg-teal-lt"
        />
        <StatCard 
          icon={<RotateCcw className="text-purple-brand" size={20} />}
          label="Ciclos sin desc."
          value={state.ciclosSinDescargaExtra}
          sub="consecutivos"
          bgColor="bg-purple-lt"
        />
        <StatCard 
          icon={<Frown className="text-amber-brand" size={20} />}
          label="Fatiga media"
          value={avgFatiga}
          sub="reciente (0–5)"
          bgColor="bg-amber-lt"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <div className="glass-card p-4 md:p-6">
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <div>
              <h3 className="font-bold text-sm md:text-base">Resumen de Progreso</h3>
              <p className="text-[9px] md:text-[10px] text-app-muted font-medium uppercase tracking-wider">Sesiones por mesociclo</p>
            </div>
            <button 
              onClick={() => onSwitchTab('progresion')}
              className="text-primary text-[10px] md:text-xs font-bold flex items-center gap-1 hover:underline"
            >
              Ver todo <ArrowRight size={12} className="md:w-[14px] md:h-[14px]" />
            </button>
          </div>

          <div className="space-y-3 md:space-y-4">
            {state.mesociclosGenerados.length === 0 ? (
              <div className="text-center py-6 md:py-8">
                <div className="text-2xl md:text-3xl mb-2">📊</div>
                <p className="text-[10px] md:text-xs text-app-muted">Genera un mesociclo para ver el progreso</p>
              </div>
            ) : (
              state.mesociclosGenerados.slice(-3).reverse().map(meso => {
                const num = meso.num;
                let mesoTotal = 0;
                let mesoDone = 0;
                for (let s = 1; s <= 4; s++) {
                  Object.keys(meso.datos).forEach(dk => {
                    if (meso.datos[dk].ejercicios.length > 0) {
                      mesoTotal++;
                      if (state.tracking[num]?.[s]?.[dk]?.completada) mesoDone++;
                    }
                  });
                }
                const pct = mesoTotal > 0 ? Math.round((mesoDone / mesoTotal) * 100) : 0;
                return (
                  <div key={num} className="space-y-1.5 md:space-y-2">
                    <div className="flex justify-between text-[10px] md:text-xs font-bold">
                      <span>Mesociclo #{num}</span>
                      <span className="text-app-muted">{mesoDone}/{mesoTotal} sesiones · {pct}%</span>
                    </div>
                    <div className="h-1.5 md:h-2 bg-app-bg rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full transition-all duration-1000",
                          pct === 100 ? "bg-teal-brand" : pct > 50 ? "bg-blue-brand" : "bg-primary"
                        )}
                        style={{ width: `${pct}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="glass-card p-4 md:p-6">
          <h3 className="font-bold mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
            <TrendingUp size={16} className="text-primary md:w-[18px] md:h-[18px]" />
            Guía de Progresión
          </h3>
          <ul className="space-y-2 md:space-y-3">
            <GuideItem 
              type="comp" 
              title="COMPUESTO (Ondulante)" 
              desc="S1-S3 ↑kg/↓reps. S4 = Descarga." 
            />
            <GuideItem 
              type="anal" 
              title="ANALÍTICO (Doble Prog.)" 
              desc="↑reps hasta techo → ↑kg y reinicia reps." 
            />
            <GuideItem 
              type="warn" 
              title="RIR" 
              desc="Si cae bajo objetivo en serie 1, mantener carga." 
            />
            <GuideItem 
              type="warn" 
              title="Regla 3 ciclos" 
              desc="3 ciclos sin descarga → Descarga en sem 10." 
            />
          </ul>
        </div>
      </div>

      {/* Fatigue Chart */}
      <div className="glass-card p-4 md:p-6">
        <div className="flex items-center justify-between mb-4 md:mb-6">
          <div>
            <h3 className="font-bold text-sm md:text-base">Historial de Fatiga</h3>
            <p className="text-[9px] md:text-[10px] text-app-muted font-medium uppercase tracking-wider">Últimas sesiones completadas</p>
          </div>
        </div>
        
        {fatigaHistory.length === 0 ? (
          <div className="text-center py-8 md:py-12 border-2 border-dashed border-app-border rounded-xl md:rounded-2xl">
            <p className="text-app-muted text-[10px] md:text-xs">Completa sesiones para ver el historial de fatiga</p>
          </div>
        ) : (
          <div className="space-y-3 md:space-y-4">
            <div className="flex items-end gap-1 md:gap-1.5 h-16 md:h-24 px-1 md:px-2">
              {fatigaHistory.slice(-20).map((f, i) => {
                const h = (f / 5) * 100;
                const color = f <= 1 ? 'bg-teal-brand' : f <= 2 ? 'bg-[#85C720]' : f <= 3 ? 'bg-amber-brand' : f <= 4 ? 'bg-[#FF7A44]' : 'bg-red-deload';
                return (
                  <div 
                    key={i} 
                    className={cn("flex-1 rounded-t-sm transition-all duration-500 hover:opacity-100 opacity-80", color)}
                    style={{ height: `${h}%` }}
                    title={`Fatiga: ${f.toFixed(1)}/5`}
                  ></div>
                );
              })}
            </div>
            <div className="flex justify-between text-[10px] text-app-muted font-bold uppercase tracking-widest border-t border-app-border pt-3">
              <span>← Más antiguo</span>
              <div className="flex gap-4">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-teal-brand"></span> Baja</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-brand"></span> Moderada</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-deload"></span> Alta</span>
              </div>
              <span>Más reciente →</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub, bgColor }: { icon: React.ReactNode, label: string, value: string | number, sub: string, bgColor: string }) {
  return (
    <div className="glass-card p-3 md:p-5 flex flex-col gap-2 md:gap-3">
      <div className={cn("w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center", bgColor)}>
        {icon}
      </div>
      <div>
        <div className="text-[9px] md:text-[10px] font-bold text-app-muted uppercase tracking-widest mb-0.5 md:mb-1">{label}</div>
        <div className="text-2xl md:text-3xl font-extrabold tracking-tight leading-none">{value}</div>
        <div className="text-[9px] md:text-[10px] text-app-muted font-medium mt-1 md:mt-1.5">{sub}</div>
      </div>
    </div>
  );
}

function GuideItem({ type, title, desc }: { type: 'comp' | 'anal' | 'warn', title: string, desc: string }) {
  const borderColor = type === 'comp' ? 'border-primary' : type === 'anal' ? 'border-teal-brand' : 'border-amber-brand';
  return (
    <li className={cn("p-3 rounded-xl bg-app-bg border-l-4 text-xs leading-relaxed", borderColor)}>
      <strong className="block mb-0.5">{title}:</strong>
      <span className="text-app-text/70">{desc}</span>
    </li>
  );
}
